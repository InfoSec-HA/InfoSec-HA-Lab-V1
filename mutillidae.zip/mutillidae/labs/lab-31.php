<?php
    $lLabNumber = 31;
    $lTitle = "Lab 31: Attacking Users with other Techniques - HTML 5 Web Storage - Capturing HTML 5 Web Storage";
    $lQuestion = "Complete the lab on Capturing HTML5 Web Storage. Use a cross-site script to extract the records from the HTML5 database. How many times did Chuck count to infinity?";
    $lChoice_1 = "once";
    $lChoice_2 = "twice";
    $lChoice_3 = "thrice";
    $lChoice_4 = "four times";
    $lChoice_5 = "five times";
    $lCorrectAnswer = 2;

    require_once("labs/lab-template.inc");
?>