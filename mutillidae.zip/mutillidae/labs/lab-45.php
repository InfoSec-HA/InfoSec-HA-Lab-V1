<?php
$lLabNumber = 45;
$lTitle = "Lab 45: Error Handling - Creating Injection Files";
$lQuestion = "What does the python script do? python3 -c 'for i in [0x00]: print(chr(i));' &gt; file.txt";
$lChoice_1 = "Nothing";
$lChoice_2 = "Overwrites a file named 0x00";
$lChoice_3 = "Prints a null character to the screen";
$lChoice_4 = "Inserts a null character into file.txt";
$lChoice_5 = "Creates 10 new files";
$lCorrectAnswer = 4;

require_once("labs/lab-template.inc");
?>