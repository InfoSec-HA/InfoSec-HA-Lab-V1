<?php
    $lLabNumber = 2;
    $lTitle = "Lab 2: Capturing HTTP Packets with Wireshark";
    $lQuestion = "Use the Firefox browser to connect to Mutillidae. What is the first word in the user-agent string?";
    $lChoice_1 = "Firefox";
    $lChoice_2 = "Gecko";
    $lChoice_3 = "Linux";
    $lChoice_4 = "Mozilla";
    $lChoice_5 = "Trident";
    $lCorrectAnswer = 4;

    require_once("labs/lab-template.inc");
?>