<?php
    $lLabNumber = 18;
    $lTitle = "Lab 18: Insecure Direct Object References - Edit Another User's Profile";
    $lQuestion = "Using an insecure direct object reference within the Edit User Profile functionality, which user has the user id (UID) of 5?";
    $lChoice_1 = "john";
    $lChoice_2 = "adrian";
    $lChoice_3 = "jeremy";
    $lChoice_4 = "kevin";
    $lChoice_5 = "bryce";
    $lCorrectAnswer = 5;

    require_once("labs/lab-template.inc");
?>