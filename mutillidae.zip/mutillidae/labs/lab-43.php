<?php
$lLabNumber = 43;
$lTitle = "Lab 43: Input Validation - File Identification";
$lQuestion = "What type of file is File10?";
$lChoice_1 = "JPEG";
$lChoice_2 = "PNG";
$lChoice_3 = "GIF";
$lChoice_4 = "ELF";
$lChoice_5 = "EXE";
$lCorrectAnswer = 2;

require_once("labs/lab-template.inc");
?>