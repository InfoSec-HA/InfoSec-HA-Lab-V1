    <?php
    $lLabNumber = 6;
    $lTitle = "Lab 6: SQL Injection - Testing for SQL Errors";
    $lQuestion = "Referring to the user-info page, which PHP file contains the source code vulnerable to SQL injection?";
    $lChoice_1 = "MySQLHandler.php";
    $lChoice_2 = "user-info.php";
    $lChoice_3 = "constants.php";
    $lChoice_4 = "index.php";
    $lChoice_5 = "ddsmoothmenu.js";
    $lCorrectAnswer = 1;

    require_once("labs/lab-template.inc");
?>