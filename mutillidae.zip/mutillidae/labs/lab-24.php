<?php
    $lLabNumber = 24;
    $lTitle = "Lab 24: Open Redirects - Part 2";
    $lQuestion = "What domain name has been encoded? %77%77%77%2E%64%75%63%6B%64%75%63%6B%67%6F%2E%63%6F%6D";
    $lChoice_1 = "www.google.com";
    $lChoice_2 = "www.walmart.com";
    $lChoice_3 = "www.duckduckgo.com";
    $lChoice_4 = "ftp.microsoft.com";
    $lChoice_5 = "www.dundermifflin.com";
    $lCorrectAnswer = 3;

    require_once("labs/lab-template.inc");
?>