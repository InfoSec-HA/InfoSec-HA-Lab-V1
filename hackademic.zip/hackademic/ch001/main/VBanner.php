<?php 
/** 
 *    ----------------------------------------------------------------
 *    OWASP Hackademic Challenges Project
 *    ----------------------------------------------------------------
 *    Copyright (C) 2010-2011 
 *   	  Andreas Venieris [venieris@owasp.gr]
 *   	  Anastasios Stasinopoulos [anast@owasp.gr]
 *    ----------------------------------------------------------------
 */
?>
<html>

<head>
<meta http-equiv="Content-Language" content="el">
<meta name="GENERATOR" content="Microsoft FrontPage 12.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1253">
<title>New Page 1</title>
<base target="main">
<style fprolloverstyle>A:hover {color: red; font-weight: bold}
</style>
<style type="text/css">
.style1 {
	font-size: x-small;
}
.style2 {
	font-size: x-small;
	color: #00FF00;
}
.style3 {
	font-size: small;
}
.style4 {
	border-style: solid;
	border-width: 1px;
	padding: 1px 4px;
	font-size: small;
	color: #00FF00;
}
</style>
</head>

<body bgcolor="#C0C0C0">

<div style="width: 224; height: 764; background-color: #C0C0C0">
  <div style="border-style: solid; border-width: 1; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1; background-color: #808080" class="style2">
    <font size="2">Aims</font></div>
  <ul type="square">
    <li class="style3"><a href="Sociability.htm">Sociability</a></li>
	<li class="style1"><span lang="el" class="style3">
	<a href="expa.htm">Expandability</a></span></li>
    <li><span lang="el" class="style3"><a href="Pubpro.htm">Public Profile </a></span></li>
  </ul>
  <div style="background-color: #808080" class="style4">
    Funds Management and Promotion</div>
  <ul type="square">
    <li class="style1"><span class="style3">Investments and shares buying </span></li>
    <li><span lang="el" class="style3">Main advertisement campaigns in the media</span></li>
	<li><span lang="el" class="style3">Approaching new Customers through Social Engineering techniques</span></font></li>
	<li class="style3">Funding for the finding of new "suppliers"!</li>
  </ul>
  <div style="background-color: #808080" class="style4">
    Main Tasks</div>
  <ul type="square">
    <li><span lang="el" class="style3"><a href="Diaxirisths.php">Send e-mail</a></span></li>
    <li><a href="mails.php"><span lang="en-us" class="style3">Mailbox </span>
	<span class="style3">Special Clients' Mailbox</span><font size="2"><span lang="el"> </span></font></a></li>
  </ul>
</div>

</body>

</html>
