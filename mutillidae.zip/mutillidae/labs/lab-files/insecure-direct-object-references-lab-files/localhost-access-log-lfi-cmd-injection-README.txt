This file is an example of a Metasploit Meterpreter PHP stager, so easily mistaken for "malware". However, the intent of this file is only to perform labs in the web application security testing course. Malicious use is strictly forbidden and a violation of the terms of use. The file is encrypted to prevent Microsoft Defender Anti-Virus throwing a false positive when this proejct is downloaded from GitHub using the ZIP file option. 

The file is zipped and encrypted using the password "mutillidae". To decrypt the file, use the follwing command:

unzip localhost-access-log-lfi-cmd-injection-README.zip (enter password "mutillidae" when prompted)

